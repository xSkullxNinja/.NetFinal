﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalProject.Enums
{
    public enum pokemonType
    {
        NORMAL,
        GRASS,
        FIRE,
        WATER,
        ELECTRIC,
        FIGHTING,
        PSYCHIC,
        STEEL,
        DARK,
        DRAGON,
        FAIRY
    }
}