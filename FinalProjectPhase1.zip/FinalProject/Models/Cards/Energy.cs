﻿using FinalProject.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalProject.Models
{
    public class Energy : PokemonCard
    {
        #region Properties
        public pokemonType Type { get; set; }
        #endregion
    }
}