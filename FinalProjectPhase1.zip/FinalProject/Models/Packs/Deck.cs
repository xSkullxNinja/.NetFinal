﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalProject.Models.Packs
{
    public class Deck
    {
        #region Properties
        public PokemonCard[] Cards { get; set; }
        #endregion
    }
}